This repository contains the sourcecode for the Chameleon Control Program
(Chaco) and related offspring (chacocmd, updater, chcodenet...).

Please read license.txt

For more information have a look at our WIKI: http://wiki.icomp.de/wiki/Chameleon

We accept patches in unified diff/patch format.

If you have further questions contact me at tobias@icomp.de

WARNING:

the repository is currently under construction and may be incomplete and not
represent the current state of the programs contained in the official update
archives.

PLEASE UNDERSTAND THAT WE CAN NOT GIVE ANY FURTHER SUPPORT ON HOW TO USE, HOW
TO COMPILE, OR HOW TO DO ANYTHING ELSE WITH THE CODE CONTAINED HERE.
