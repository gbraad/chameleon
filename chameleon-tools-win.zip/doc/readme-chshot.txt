chshot - make screenshot from C64 screen over USB

$ chshot
chshot 0.1 (compiled on Oct 28 2015)
usage: chshot <options>

-h --help          this help
--verbose          enable verbose messages
--debug            enable debug messages

-o Filename        save screenshot

NOTE: since the USB connection is kindof slow, this tool has very limited use.
